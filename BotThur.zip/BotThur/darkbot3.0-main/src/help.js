const //database
	return `
╔══✪〘 INFO 〙✪══
║
╠➥ ThurBot 
╠➥ *1.0*
╠➥ 𝐃𝐎𝐍𝐎:  ThurMaker 
╠➥ *wa.me/+5564992551969*
╠➥ 𝐒𝐓𝐀𝐓𝐔𝐒: ON
║
╠══✪〘 NOVIDADES 〙✪══
║
║*${prefix}play (nome da msc)*
║
╠══✪〘 MENU 〙✪══
║
║1 *${prefix}figu*
║2 *${prefix}toimg*
║3 *${prefix}meme*
║4 *${prefix}memeindo*
║5 *${prefix}tts*
║6 *${prefix}lolih [on]*
║7 *${prefix}nsfwloli [off]*
║8 *${prefix}url2img*
║9 *${prefix}leens [na legenda]*
║10 *${prefix}wait [na legenda]*
║11 *${prefix}setprefix*
║
╠══✪〘 OUTROS 〙✪══
║
║12 *${prefix}bemvindo [1/0]*
║13 *${prefix}dono*
║14 *${prefix}bomdia*
║15 *${prefix}boanoite*
╠══✪〘 GRUPO 〙✪══
║
║16 *${prefix}bemvindo [1/0]*
║17 *${prefix}grupoinfo*
║18 *${prefix}bomdia*
║19 *${prefix}boatarde*
║20 *${prefix}boanoite*
║21 *${prefix}setdesc*
║22 *${prefix}bug [sua mensagem]*
║
╠══✪〘 𝗗𝗢𝗡𝗢 〙✪══
║
║ *NOME: ThurMaker*
║ *WPP: wa.me/+5564992551969*
║
║  *"Peita ou respeita 🐊🚩*
║
║
╚═〘 Thur Bot 〙`
}

//Online.database

